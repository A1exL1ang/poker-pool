"""Offline equity assets with a small standard-library inference runtime.

Missing assets use explicit deterministic heuristic fallbacks, reported by
``asset_status()``. The model is a range-equity approximation, not a solver.
"""

import json
import math
from pathlib import Path

from poker_eval import FEATURE_NAMES, features

_ROOT = Path(__file__).resolve().parent
_MODEL = None
_PREFLOP = None
_LOAD_ERRORS = []


def _validate_model(data):
    if data.get("feature_names") != list(FEATURE_NAMES):
        raise ValueError("model feature schema mismatch")
    streets = data["streets"]
    if set(streets) != {"3", "4", "5"}:
        raise ValueError("incomplete street models")
    for model in streets.values():
        if not math.isfinite(model["base"]) or not model["trees"]:
            raise ValueError("invalid base or empty forest")
        immutable = []
        for tree in model["trees"]:
            if not tree:
                raise ValueError("empty tree")
            for node_id, entry in enumerate(tree):
                if not isinstance(entry[0], int) or not math.isfinite(entry[1]):
                    raise ValueError("nonfinite model value")
                if entry[0] < 0:
                    if len(entry) != 2:
                        raise ValueError("malformed leaf")
                elif not (len(entry) == 4 and 0 <= entry[0] < 43 and
                          node_id < entry[2] < len(tree) and node_id < entry[3] < len(tree)):
                    raise ValueError("malformed or cyclic tree")
            immutable.append(tuple(tuple(entry) for entry in tree))
        model["trees"] = tuple(immutable)
    return data


def _validate_preflop(data):
    if len(data["base"]) != 169 or len(data["percentile"]) != 169:
        raise ValueError("preflop class count")
    widths = data["widths"]
    if len(widths) < 2 or widths != sorted(set(widths)) or widths[0] > .05 or widths[-1] != 1:
        raise ValueError("preflop width grid")
    if len(data["equity"]) != 169 * len(widths) * 7:
        raise ValueError("preflop cell count")
    for key in ("base", "percentile", "equity"):
        if any(not math.isfinite(x) or not 0 <= x <= 1 for x in data[key]):
            raise ValueError("invalid preflop probability")
        data[key] = tuple(data[key])
    data["widths"] = tuple(widths)
    return data


for _name, _file in (("model", "equity_model.json"), ("preflop", "preflop.json")):
    try:
        with (_ROOT / "assets" / _file).open("r", encoding="utf-8") as _stream:
            _data = json.load(_stream)
        if _data.get("schema") != 1:
            raise ValueError("unsupported asset schema")
        if _name == "model":
            _MODEL = _validate_model(_data)
        else:
            _PREFLOP = _validate_preflop(_data)
    except (OSError, ValueError, KeyError, TypeError, IndexError) as _error:
        _LOAD_ERRORS.append(f"{_file}: {type(_error).__name__}")


def asset_status():
    return {"postflop_model": _MODEL is not None, "preflop_table": _PREFLOP is not None,
            "load_errors": list(_LOAD_ERRORS)}


def preflop_class(hole):
    a, b = hole
    hi, lo = max(a >> 2, b >> 2), min(a >> 2, b >> 2)
    return hi * 13 + lo if a & 3 == b & 3 else lo * 13 + hi


def _fallback_base(hole):
    a, b = hole
    hi, lo = max(a >> 2, b >> 2) + 2, min(a >> 2, b >> 2) + 2
    if hi == lo:
        return .50 + .029 * (hi - 2)
    return min(.69, .29 + .019 * hi + .007 * lo + .025 * (a & 3 == b & 3) - .007 * max(0, hi - lo - 2))


def preflop_percentile(hole):
    """Top fraction of 1,326 holdings; AA is near zero, weakest near one."""
    if _PREFLOP is not None:
        return _PREFLOP["percentile"][preflop_class(hole)]
    return max(.002, min(.999, 1.0 - (_fallback_base(hole) - .32) / .50))


def preflop_equity(hole, width=1.0, opponents=1):
    """Interpolate table showdown share against 1..7 blocked range draws."""
    n = max(1, min(7, int(opponents)))
    w = max(.05, min(1.0, float(width)))
    if _PREFLOP is None:
        base = _fallback_base(hole)
        tight_penalty = .12 * (1 - w) * (1.0 - base)
        return max(.005, min(.995, (base - tight_penalty) ** (n ** .78)))
    widths = _PREFLOP["widths"]
    k = 0
    while k < len(widths) - 2 and w > widths[k + 1]:
        k += 1
    alpha = (w - widths[k]) / (widths[k + 1] - widths[k])
    offset = (preflop_class(hole) * len(widths) + k) * 7 + n - 1
    values = _PREFLOP["equity"]
    return values[offset] * (1 - alpha) + values[offset + 7] * alpha


def _fallback_equity(f):
    cat, top, boardcat = int(f[6]), f[7], int(f[34])
    if cat >= 6:
        q = .985 if cat > boardcat else .52
    elif cat == 5:
        q = .965 if f[23] else .52
    elif cat == 4:
        q = .90 if f[38] else .50
    elif cat == 3:
        q = .86 if cat > boardcat else .45 + .015 * (f[1] - 8)
    elif cat == 2:
        q = .79 if boardcat == 0 else .66 if boardcat == 1 else .42
    elif cat == 1:
        if f[3]:
            q = .76 if f[31] == 0 else .59 if f[31] == 1 else .43
        elif f[29] or f[30]:
            q = .70 if top >= f[12] else .54 if top >= f[13] else .42
        else:
            q = .30 + .015 * (f[1] - 8)
    else:
        q = .19 + .018 * (f[1] - 8) + .035 * f[28]
    if f[0] < 5:
        if f[22] == 4 and f[23] > 0:
            q += .13 if f[0] == 3 else .08
        if f[39] and f[27]:
            q += .045 * min(2, f[27])
    q -= (.06 * (1 - f[41]) + .16 * f[42]) * (1.02 - q)
    return max(.01, min(.99, q))


def predict_from_features(f):
    """Predict heads-up pot share; last two features are width/aggression."""
    if _MODEL is None:
        return _fallback_equity(f)
    model = _MODEL["streets"][str(int(f[0]))]
    value = model["base"]
    for tree in model["trees"]:
        node = 0
        while True:
            entry = tree[node]
            index = entry[0]
            if index < 0:
                value += entry[1]
                break
            node = entry[2] if f[index] < entry[1] else entry[3]
    return max(.001, min(.999, value))


def predict_equity(hole, board, range_width=1.0, aggression=0.0):
    return predict_from_features(features(hole, board, range_width, aggression))
