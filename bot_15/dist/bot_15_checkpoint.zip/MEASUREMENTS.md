# Checkpoint measurements — final held-out evaluation pending

The policy and model are frozen, and this checkpoint is runnable offline. The final report will replace this file after the queued private evaluation completes.

- 68 unit/regression tests pass.
- Independent evaluator audit: all 2,598,960 five-card hands and 10,000 seven-card hands pass; 19,664 native/Python feature comparisons pass.
- Eight-tree equity model: 12,000 held-out hands, MAE 0.017264, RMSE 0.025904. Asset size 5,160,408 bytes.
- Policy selected from 53,248 tuning table runs; the selected policy's gain over untuned is statistically uncertain.
- Frozen-policy Windows timing: 138,520 full `act()` calls, median 50.7us, p99 283.7us, p99.9 586.6us, maximum 5435.4us; 29 calls exceeded 1ms, zero internal error fallbacks. Loading/initialization excluded.

The official interface, full blind schedule, payout vector, and timing hardware are unknown. No official compatibility or payout claims are made, and no hard 1ms guarantee is claimed. This is local experimentation, not contest submission. Raw measurements and source are retained in the workspace.
