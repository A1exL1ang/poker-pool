#!/usr/bin/env bash
#SBATCH --job-name=bot_20_final_clean
#SBATCH --partition=mit_preemptable
#SBATCH --cpus-per-task=8
#SBATCH --mem=16G
#SBATCH --time=00:30:00
#SBATCH --output=job_%j.log
set -euo pipefail
cd "$HOME/poker-pool-extended-20261106/bot_20"
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
printf 'bot_20 own opaque-ID evaluation %s started %s\n' "$SLURM_JOB_ID" "$(date -u +%FT%TZ)"
python3 -m benchmarks.freeze
python3 -m unittest discover -s tests -v > measurements/tests_final.txt 2>&1
python3 -m benchmarks.latency --tables 20 --limit 16000 --repeats 4 --output measurements/latency_final.json
python3 -m benchmarks.stress_latency
python3 -m benchmarks.final_eval --tables 512 --workers 8 --seed-start 190000000 --output measurements/final_tournaments.json
python3 -m benchmarks.package --output artifacts/bot_20.zip --report measurements/package_verification.json
printf 'bot_20 own opaque-ID evaluation %s completed %s\n' "$SLURM_JOB_ID" "$(date -u +%FT%TZ)"
