#!/usr/bin/env bash
#SBATCH --job-name=bot_20_validation
#SBATCH --partition=mit_preemptable
#SBATCH --cpus-per-task=8
#SBATCH --mem=16G
#SBATCH --time=00:20:00
#SBATCH --output=job_%j.log
set -euo pipefail
cd "$HOME/poker-pool-extended-20261106/bot_20"
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
printf 'bot_20 own validation %s started %s\n' "$SLURM_JOB_ID" "$(date -u +%FT%TZ)"
python3 -m unittest discover -s tests -v > measurements/tests_latest.txt 2>&1
python3 -m benchmarks.policy_sweep --tables 512 --workers 8 --names base,less_bluff --seed-start 5000000 --output measurements/policy_validation.json
python3 -m benchmarks.package --output artifacts/validation_package.zip --report measurements/package_validation.json
printf 'bot_20 own validation %s completed %s\n' "$SLURM_JOB_ID" "$(date -u +%FT%TZ)"
