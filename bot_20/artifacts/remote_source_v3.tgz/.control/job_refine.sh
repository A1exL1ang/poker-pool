#!/usr/bin/env bash
#SBATCH --job-name=bot_20_equity_v3
#SBATCH --partition=mit_preemptable
#SBATCH --cpus-per-task=8
#SBATCH --mem=16G
#SBATCH --time=00:30:00
#SBATCH --output=job_%j.log
set -euo pipefail
cd "$HOME/poker-pool-extended-20261106/bot_20"
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
printf 'bot_20 own refinement %s started %s\n' "$SLURM_JOB_ID" "$(date -u +%FT%TZ)"
training/generate --mode postflop --order training/data/order.csv --rows 1000000 --samples 512 --seed 471029 --out training/data/train_large.npy
python3 training/experiment_equity.py --train training/data/train_large.npy --candidates street48,street64,street96 --output-dir training/candidates_v2 --report measurements/equity_experiments_v2.json
python3 -m unittest discover -s tests -q
printf 'bot_20 own refinement %s completed %s\n' "$SLURM_JOB_ID" "$(date -u +%FT%TZ)"
