# Independent equity training

Gameplay uses Python's standard library only. Training additionally needs a
C++17 compiler, NumPy, and scikit-learn. OpenMP parallelizes independent sample
rows; choose at most eight threads in this team's authorized compute job.

Run `bash training/run_training.sh` from the workspace. This creates a preflop
table and a compact model in `pokerbot/assets`. No code downloads or online calls
occur. The two training seeds and validation seed are distinct. The validation
file is available for model selection; it is **not** held-out final evidence.

After freezing the model, create and evaluate the final set:

```sh
training/generate --mode postflop --order training/data/order.csv --rows 12000 --samples 2048 --seed 991237 --out training/data/final_test.npy
python3 training/evaluate_equity.py --test training/data/final_test.npy
```

Preflop ordering is the average showdown share of each of 169 classes against a
uniform random hand, estimated from 30,000 independent runouts per class. Class
indices use a 13 by 13 ascending-rank matrix: below-diagonal suited, above-
diagonal offsuit, and paired diagonal. Combination weights (4, 12, and 6) turn
the ordering into percentiles. The table estimates equity on eight range
fractions and seven opponent counts, including ties; fraction interpolation is
logarithmic. Its Monte Carlo standard errors are stored alongside the cells.

A modeled opponent's preflop weight is 1 inside the chosen top-fraction range
and `0.02 * exp(-6 * (percentile - fraction))` outside it. The full-range setting
is uniform. The small tail ensures support after blockers even in multiway
pots. This is a deliberately documented range family, not a claim about actual
opponents or equilibrium ranges.

Postflop pressure interpolates between that preflop range and a range weighted
by `0.02 + 3 * current_hand_percentile**6 + draw_quality`. Current hand percentile
comes from exact present-street ranks of all two-card holdings consistent with
the board. Draw quality gives additional weight to private-card-assisted flush
and straight draws. No future board card enters these weights. Each simulated
opponent hand is sampled from this range conditioned on the cards already
drawn; this sequential conditional sampling is an approximation to jointly
conditioning independent ranges on disjoint hands. We then draw the remaining
board uniformly and record the hero's exact pot share, including multiway ties.

Features use only the hero's hole cards and public board, with suit and hole-
order invariance. The model additionally receives opponent count, range
fraction, pressure, and hero preflop percentile. Exported trees use ordinary
numeric comparisons and floats; their predictions are checked against the
training library before export is accepted. A model/schema failure exposes
`model_loaded=False` and retains an analytic fallback for interface bring-up.
The final bot should package both trained assets and verify those flags.

The final equity test measures approximation of this specific range model,
not playing strength. Its labels retain Monte Carlo uncertainty, reported as
an estimated noise floor. Tournament tests must independently evaluate policy
quality, payout sensitivity, opponent adaptation, and 1 ms action latency.
