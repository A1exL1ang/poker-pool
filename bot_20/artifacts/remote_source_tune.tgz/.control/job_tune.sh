#!/usr/bin/env bash
#SBATCH --job-name=bot_20_policy_tune
#SBATCH --partition=mit_preemptable
#SBATCH --cpus-per-task=8
#SBATCH --mem=16G
#SBATCH --time=01:00:00
#SBATCH --output=job_%j.log
set -euo pipefail
cd "$HOME/poker-pool-extended-20261106/bot_20"
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
printf 'bot_20 own policy tuning %s started %s\n' "$SLURM_JOB_ID" "$(date -u +%FT%TZ)"
g++ -O3 -std=c++17 -fopenmp training/generate.cpp -o training/generate
training/generate --mode preflop --order training/data/order.csv --samples 12000 --seed 327119 --out pokerbot/assets/preflop.json
python3 -m unittest discover -s tests -v > measurements/tests_before_tuning.txt 2>&1
python3 training/validate_evaluator.py
python3 training/diagnose_equity.py --report measurements/equity_selected_validation_worst.json
python3 -m benchmarks.latency --tables 16 --limit 12000 --repeats 3 --output measurements/latency_linux_selected.json
python3 -m benchmarks.stress_latency
python3 -m benchmarks.policy_sweep --tables 128 --workers 8 --output measurements/policy_sweep.json
printf 'bot_20 own policy tuning %s completed %s\n' "$SLURM_JOB_ID" "$(date -u +%FT%TZ)"
