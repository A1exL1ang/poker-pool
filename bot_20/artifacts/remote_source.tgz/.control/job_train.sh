#!/usr/bin/env bash
#SBATCH --job-name=bot_20_equity_v1
#SBATCH --partition=mit_preemptable
#SBATCH --cpus-per-task=8
#SBATCH --mem=16G
#SBATCH --time=01:00:00
#SBATCH --output=job_%j.log
set -euo pipefail
cd "$HOME/poker-pool-extended-20261106/bot_20"
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
printf 'bot_20 own training job %s started %s\n' "$SLURM_JOB_ID" "$(date -u +%FT%TZ)"
python3 -c 'import platform, sklearn, numpy; print(platform.python_version(), "sklearn",sklearn.__version__,"numpy",numpy.__version__)'
bash training/run_training.sh
python3 -m unittest discover -s tests -q
printf 'bot_20 own training job %s completed %s\n' "$SLURM_JOB_ID" "$(date -u +%FT%TZ)"
