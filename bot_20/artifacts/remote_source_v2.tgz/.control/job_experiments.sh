#!/usr/bin/env bash
#SBATCH --job-name=bot_20_models_v2
#SBATCH --partition=mit_preemptable
#SBATCH --cpus-per-task=8
#SBATCH --mem=16G
#SBATCH --time=00:30:00
#SBATCH --output=job_%j.log
set -euo pipefail
cd "$HOME/poker-pool-extended-20261106/bot_20"
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
printf 'bot_20 own model experiment %s started %s\n' "$SLURM_JOB_ID" "$(date -u +%FT%TZ)"
python3 training/experiment_equity.py
python3 training/diagnose_equity.py
python3 -m benchmarks.latency --tables 12 --limit 10000 --repeats 3 --output measurements/latency_linux_v1.json
printf 'bot_20 own experiment %s completed %s\n' "$SLURM_JOB_ID" "$(date -u +%FT%TZ)"
