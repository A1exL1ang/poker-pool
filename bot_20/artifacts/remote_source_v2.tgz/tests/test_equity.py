import itertools
import random
import unittest

from pokerbot.equity import EquityEstimator, hand_class, preflop_percentile
from pokerbot.evaluator import card_id
from pokerbot.features import extract_features


def cards(text):
    return tuple(card_id(c) for c in text.split())


class EquityTests(unittest.TestCase):
    def test_hand_classes(self):
        represented = {hand_class((a, b)) for a in range(52) for b in range(a + 1, 52)}
        self.assertEqual(represented, set(range(169)))
        self.assertEqual(hand_class(cards("As Kd")), hand_class(cards("Ah Kc")))
        self.assertNotEqual(hand_class(cards("As Ks")), hand_class(cards("As Kd")))

    def test_order(self):
        self.assertLess(preflop_percentile(cards("As Ah")), preflop_percentile(cards("2s 7h")))

    def test_royals_and_empty_opponents(self):
        model = EquityEstimator()
        self.assertEqual(model.estimate(cards("As Ks"), cards("Qs Js Ts 2d 3c"), 7), 1)
        self.assertEqual(model.estimate(cards("2d 3c"), cards("As Ks Qs Js Ts"), 7), .125)
        self.assertEqual(model.estimate(cards("2d 3c"), cards("As Ks Qs Js Ts"), 0), 1)

    def test_feature_suit_invariance(self):
        rng = random.Random(813218)
        for _ in range(100):
            sample = rng.sample(range(52), rng.choice((5, 6, 7)))
            before = extract_features(sample[:2], sample[2:])
            for permutation in itertools.permutations(range(4)):
                after_cards = [(c & ~3) + permutation[c & 3] for c in sample]
                after = extract_features(after_cards[:2], after_cards[2:])
                self.assertEqual(before, after)

    def test_bounded_and_reused_features(self):
        rng = random.Random(177201)
        model = EquityEstimator()
        for _ in range(300):
            sample = rng.sample(range(52), rng.choice((5, 6, 7)))
            hole, board = sample[:2], sample[2:]
            n, fraction, pressure = rng.randrange(1, 8), rng.uniform(.05, 1), rng.random()
            prediction = model.estimate(hole, board, n, fraction, pressure)
            self.assertEqual(prediction, model.predict(extract_features(hole, board), n, fraction, pressure))
            self.assertGreaterEqual(prediction, 0)
            self.assertLessEqual(prediction, 1)

    def test_explicit_missing_model_fallback(self):
        model = EquityEstimator(model_path="nonexistent-bot20-model.gz", preflop_path="nonexistent-bot20-preflop.json")
        self.assertFalse(model.model_loaded)
        self.assertFalse(model.preflop_loaded)
        self.assertGreater(model.estimate(cards("As Ah"), (), 1), model.estimate(cards("2s 7h"), (), 1))

    def test_compiled_predictor_matches_interpreter(self):
        model = EquityEstimator()
        if not model.model_loaded:
            self.skipTest("Trained asset not present")
        rng = random.Random(512611)
        for _ in range(1000):
            sample = rng.sample(range(52), rng.choice((5, 6, 7)))
            f = extract_features(sample[:2], sample[2:])
            high, low = int(f[1]) - 2, int(f[2]) - 2
            index = high * 13 + low if f[4] else low * 13 + high
            vector = (*f, rng.randint(1, 7), rng.uniform(.05, 1), rng.random(), model.preflop["percentiles"][index])
            base, trees, predictor = model._models[int(f[0])]
            expected = base
            for tree in trees:
                node = tree[0]
                while node[0] >= 0:
                    node = tree[node[2] if vector[node[0]] <= node[1] else node[3]]
                expected += node[4]
            self.assertEqual(predictor(vector), expected)
        self.assertIs(model.trees, EquityEstimator().trees)


if __name__ == "__main__":
    unittest.main()
