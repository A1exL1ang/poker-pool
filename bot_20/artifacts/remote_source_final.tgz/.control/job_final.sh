#!/usr/bin/env bash
#SBATCH --job-name=bot_20_final_eval
#SBATCH --partition=mit_preemptable
#SBATCH --cpus-per-task=8
#SBATCH --mem=16G
#SBATCH --time=00:30:00
#SBATCH --output=job_%j.log
set -euo pipefail
cd "$HOME/poker-pool-extended-20261106/bot_20"
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
printf 'bot_20 own frozen evaluation %s started %s\n' "$SLURM_JOB_ID" "$(date -u +%FT%TZ)"
python3 -m benchmarks.freeze
python3 -m unittest discover -s tests -v > measurements/tests_final.txt 2>&1
g++ -O3 -std=c++17 -fopenmp training/generate.cpp -o training/generate
training/generate --mode postflop --order training/data/order.csv --rows 12000 --samples 2048 --seed 991237 --out training/data/final_test.npy
python3 training/evaluate_equity.py --test training/data/final_test.npy --report measurements/equity_heldout.json
training/generate --mode preflop_test --order training/data/order.csv --rows 3000 --samples 4096 --seed 110327 --out training/data/preflop_test.npy
python3 training/evaluate_preflop.py --test training/data/preflop_test.npy --report measurements/preflop_heldout.json
python3 -m benchmarks.latency --tables 20 --limit 16000 --repeats 4 --output measurements/latency_final.json
python3 -m benchmarks.stress_latency
python3 -m benchmarks.final_eval --tables 512 --workers 8 --output measurements/final_tournaments.json
python3 -m benchmarks.package --output artifacts/bot_20.zip --report measurements/package_verification.json
printf 'bot_20 own frozen evaluation %s completed %s\n' "$SLURM_JOB_ID" "$(date -u +%FT%TZ)"
